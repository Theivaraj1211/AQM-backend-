module.exports = {
  pgdbHost:
    process.env.AQM_PGDB_HOST || process.env.PGDB_HOST || "iot.hyperthings.in",
  pgdbPort: process.env.AQM_PGDB_PORT || process.env.PGDB_PORT || "17050",
  pgdbIsAuth:
    process.env.AQM_PGDB_IS_AUTH || process.env.PGDB_IS_AUTH || "true",
  pgdbUsername:
    process.env.AQM_PGDB_USERNAME || process.env.PGDB_USERNAME || "root",
  pgdbPassword:
    process.env.AQM_PGDB_PASSWORD ||
    process.env.PGDB_PASSWORD ||
    "dsabnfl9opyu21906y9opicn",

  pgDbName: process.env.PGDB_NAME || "aqm-app",

  appPort: process.env.AQM_API_PORT || 3031,
  appHost: process.env.AQM_API_HOST || "0.0.0.0",

  appEnv: process.env.AQM_API_ENV || "dev",
  appLog: process.env.AQM_API_LOG || "dev",

  accessTokenSecret:
    process.env.AQM_API_ACCESS_TOKEN_SECRET ||
    "F4AE2797BA2DE610139037BE30173DCEEAFBB8ABB37CE60B81FD0BEC738F646A",
  refreshTokenSecret:
    process.env.AQM_API_REFRESH_TOKEN_SECRET ||
    "EFBF25E19309E46E1640E32322F56398D9D9726FD202DE0DCF18F199C6CE923B",

  loginAPIServer:
    process.env.AQM_DS_API ||
    process.env.DS_API ||
    "http://iot.hyperthings.in:17016/api/v1",

  dsAPIKey:
    process.env.AQM_DS_API_KEY ||
    process.env.DS_API_KEY ||
    "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0ZW5hbnRJZCI6IjVlOTlhOTAzMTQyMWZmMDAxOTk2Y2ZlNCIsImFwcElkIjoiNDY3MTEwMTQ5MTE4MzgzMSIsImlhdCI6MTU4NzEzNzA1NX0.tKRRdVGB9us6-NV-aroAnOSWao8iA95rgYwNllm-d3g",

  rawDataSchema:
    process.env.RAW_DATA_SCHEMA ||
    '{"co": "", "aqi": "", "co2": "", "no2": "", "p10": "","p25": "","so2": "","humidity": "","temperature": "","leq": "","uv": ""}',
};
