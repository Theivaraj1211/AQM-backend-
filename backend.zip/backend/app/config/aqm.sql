CREATE DATABASE "aqm-app"
\c "aqm-app"


CREATE EXTENSION IF NOT EXISTS timescaledb CASCADE;
-- public.alerts definition

-- Drop table

-- DROP TABLE public.alerts;

CREATE TABLE public.alerts (
	"time" timestamptz NOT NULL,
	id serial NOT NULL,
	"alertType" varchar(10) NOT NULL DEFAULT 'DEFAULT'::character varying,
	"alertLevel" int8 NOT NULL DEFAULT 0,
	"deviceId" varchar(30) NOT NULL,
	"rule" int4 NOT NULL,
	value varchar(20) NOT NULL,
	severity int4 NOT NULL DEFAULT 0,
	resolved bool NOT NULL DEFAULT false,
	"resolvedBy" int4 NULL,
	"resolvedAt" timestamptz NULL,
	"desc" varchar(255) NULL
);

SELECT create_hypertable('alerts', 'time');
CREATE INDEX alerts_alert_level_idx ON public.alerts USING btree ("alertLevel");
CREATE INDEX alerts_resolved_idx ON public.alerts USING btree (resolved);
CREATE INDEX alerts_severity_idx ON public.alerts USING btree (severity);


-- public.devices definition

-- Drop table

-- DROP TABLE public.devices;

CREATE TABLE public.devices (
	id serial NOT NULL,
	"isActive" bool NOT NULL,
	state bool NOT NULL,
	"deviceId" varchar(30) NOT NULL,
	"name" varchar(100) NOT NULL,
	"macAddress" varchar(30) NOT NULL,
	gateway bool NOT NULL,
	"mfrId" varchar(30) NOT NULL,
	"addedBy" varchar(30) NOT NULL,
	"protocolType" varchar(25) NOT NULL,
	lat float8 NOT NULL,
	lng float8 NOT NULL,
	address varchar(255) NOT NULL,
	site varchar(30) NOT NULL,
	"createdAt" timestamptz NOT NULL DEFAULT now(),
	"updatedAt" timestamptz NOT NULL DEFAULT now(),
	CONSTRAINT devices_pkey PRIMARY KEY (id)
);
CREATE UNIQUE INDEX devices_deviceid_idx ON public.devices USING btree ("deviceId");
CREATE INDEX devices_site_idx ON public.devices USING btree (site);

-- public.raw_data definition

-- Drop table

-- DROP TABLE public.raw_data;

CREATE TABLE public.raw_data (
	"time" timestamptz NOT NULL,
	id serial NOT NULL,
	"size" int4 NOT NULL,
	"deviceId" varchar(50) NOT NULL,
	"data" jsonb NOT NULL,
	"dataId" int4 NOT NULL,
	"dataFrom" varchar(255) NOT NULL,
	"ingestTime" timestamptz NOT NULL
);

SELECT create_hypertable('raw_data', 'time');
CREATE INDEX raw_data_deviceid_idx ON public.raw_data USING btree ("deviceId");




-- public.report_schedules definition

-- Drop table

-- DROP TABLE public.report_schedules;

CREATE TABLE public.report_schedules (
	id serial NOT NULL,
	"name" varchar(200) NOT NULL,
	frequency int2 NOT NULL,
	format varchar(20) NOT NULL,
	site varchar(30) NOT NULL,
	device varchar(30) NULL,
	"user" int4 NOT NULL,
	"createdAt" timestamptz NOT NULL DEFAULT now(),
	"updatedAt" timestamptz NOT NULL DEFAULT now(),
	"lastSentAt" timestamptz NULL,
	CONSTRAINT report_schedules_pk PRIMARY KEY (id)
);
CREATE INDEX report_schedules_frequency_idx ON public.report_schedules USING btree (frequency, "lastSentAt");


-- public.rules definition

-- Drop table

-- DROP TABLE public.rules;

CREATE TABLE public.rules (
	id serial NOT NULL,
	"name" varchar(100) NOT NULL DEFAULT ''::character varying,
	device int4 NULL,
	"deviceId" varchar(30) NULL,
	"desc" varchar(200) NULL,
	"dataPath" varchar(200) NOT NULL,
	"operator" varchar(10) NOT NULL,
	value varchar NOT NULL,
	severity int4 NOT NULL DEFAULT 0,
	"statement" varchar(100) NOT NULL,
	incharge jsonb NULL DEFAULT '{}'::jsonb,
	"createdAt" timestamptz NOT NULL DEFAULT now(),
	"updatedAt" timestamptz NOT NULL DEFAULT now(),
	CONSTRAINT rules_pk PRIMARY KEY (id)
);
CREATE INDEX rules_device_idx ON public.rules USING btree ("deviceId");


-- public.sites definition

-- Drop table

-- DROP TABLE public.sites;

CREATE TABLE public.sites (
	id serial NOT NULL,
	"name" varchar(100) NOT NULL,
	"siteId" varchar(30) NOT NULL,
	lat float8 NOT NULL,
	lng float8 NOT NULL,
	address varchar(255) NOT NULL,
	"parentId" varchar(30) NULL,
	"createdAt" timestamptz NOT NULL DEFAULT now(),
	"updatedAt" timestamptz NOT NULL DEFAULT now(),
	CONSTRAINT sites_pkey PRIMARY KEY (id)
);
CREATE INDEX sites_parentid_idx ON public.sites USING btree ("parentId");
CREATE UNIQUE INDEX sites_siteid_idx ON public.sites USING btree ("siteId");


-- public.units definition

-- Drop table

-- DROP TABLE public.units;

CREATE TABLE public.units (
	id serial NOT NULL,
	"name" varchar(50) NULL,
	"ref" varchar(50) NOT NULL,
	uom varchar(20) NULL,
	format varchar(10) NULL
);

INSERT INTO public.units ("name","ref",uom,format) VALUES 
('Pressure','p','Pa',',.00')
,('W','w','',',.00')
,('BS','bs','',',.00')
,('CO','co','mg/m³',',.00')
,('G2','g1',' ',',.00')
,('G1','g2',' ',',.00')
,('O3','o3','mg/m³',',.00')
,('UV','uv','Index',',.00')
,('CO2','co2','ppm',',.00')
,('Dew Index','dew','Index',',.00')
,('Noise','leq','dB',',.00')
,('NO2','no2','mg/m³',',.00')
,('PM10','p10','µg/m³',',.00')
,('PM2.5','p25','µg/m³',',.00')
,('SO2','so2','mg/m³',',.00')
,('Light Max','lmax','dB',',.00')
,('Light Min','lmin','dB',',.00')
,('Light','light','Lux',',.00')
,('Humidity','humidity','%',',.00')
,('Temperature','temperature','°C',',.00')
,('AQI','aqi','Index','0')
,('Time','time',' ','0')
,('Low Severity','s1',' ',' ')
,('Medium Severity','s2',' ',' ')
,('High Severity','s3',' ',' ')
,('ID','id',' ',' ')
,('Device','deviceId',' ',' ')
,('25.2854','dash_map_lat',' ',' ')
,('51.5310','dash_map_lng',' ',' ')
;

-- public.users definition

-- Drop table

-- DROP TABLE public.users;

CREATE TABLE public.users (
	id serial NOT NULL,
	"name" varchar(100) NOT NULL,
	email varchar(255) NOT NULL,
	mobile varchar(30) NOT NULL,
	address varchar(255) NOT NULL,
	"isAdmin" bool NOT NULL,
	"password" varchar(255) NOT NULL,
	"createdAt" timestamptz NOT NULL DEFAULT now(),
	"updatedAt" timestamptz NOT NULL DEFAULT now(),
	CONSTRAINT users_pkey PRIMARY KEY (id)
);
CREATE UNIQUE INDEX users_email_idx ON public.users USING btree (email);
CREATE INDEX users_mobile_idx ON public.users USING btree (mobile);