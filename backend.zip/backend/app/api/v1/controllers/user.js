"use strict";
//Import Axios
const Axios = require("axios");
//Import JWT
const Jwt = require("jsonwebtoken");
//Import Joi
const Joi = require("@hapi/joi");
//Import Bcrypt
const Bcrypt = require("bcrypt");
//Import Sequelize
const Sequelize = require("sequelize");
//User Schema
const Schema = require("./../db/models/Schema");
//Import Settings
const {
  loginAPIServer,
  dsAPIKey,
  jwtSignature,
} = require("./../../../config/adaptor");
//Import PG Models
const DB = require("./../db/models/pg");

//Import Response Util
const Response = require("../utils/response");
//Auth Controller
module.exports = class AuthHandler {
  constructor() {}
  //Signin
  static async signin(ctx, next) {
    const { email, password } = ctx.request.body;
    if (!email || !password) {
      return Response.badRequest(ctx, {
        code: 40,
        msg: "Please provide valid data !",
      });
    }
    try {
      // Check if user exists locally
      const checkUser = await DB.user.findAll({
        where: {
          email,
        },
      });
      //If exists
      if (checkUser.length == 1) {
        const passwordCheck = await Bcrypt.compareSync(
          password,
          checkUser[0]["password"]
        );
        if (!passwordCheck) {
          return Response.unauthorized(ctx, {
            statusCode: 401,
            code: 41,
            msg: "Password does not match!",
          });
        }
        //JWT generate - accessToken
        const accessToken = Jwt.sign(
          {
            id: checkUser[0]["id"],
            name: checkUser[0]["name"],
            email: checkUser[0]["email"],
            isAdmin: false,
          },
          jwtSignature.accessSecret,
          {
            expiresIn: "12h",
          }
        );
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "Successful login!",
          data: {
            name: checkUser[0]["name"],
            email: checkUser[0]["email"],
            token: accessToken,
          },
        });
      } else {
        const response = await Axios({
          method: "POST",
          url: `${loginAPIServer}/signin`,
          headers: {
            Authorization: `Bearer ${dsAPIKey}`,
          },
          data: { email, password },
        });
        //JWT generate - accessToken
        const accessToken = Jwt.sign(
          {
            id: null,
            name: response.data.data.results.name,
            email: response.data.data.results.email,
            isAdmin: true,
          },
          jwtSignature.accessSecret,
          {
            expiresIn: "12h",
          }
        );
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "Successful login!",
          data: {
            name: response.data.data.results.name,
            email: response.data.data.results.email,
            token: accessToken,
          },
        });
      }
    } catch (err) {
      console.log(err);
      if (err.response && err.response.data.error) {
        return Response.unauthorized(ctx, {
          statusCode: 401,
          code: 41,
          msg: err.response.data.error.msg,
        });
      } else {
        return Response.error(ctx, {
          statusCode: 500,
          code: 50,
          msg: "Internal Error",
          error: err,
        });
      }
    }
  }
  //All Users
  static getAllUsers = async (ctx, next) => {
    let selectFields = [];
    //Get User Schema
    const schemaObj = Schema().UserSchema;
    //Query field implementation
    if (ctx.query && ctx.query.fields) {
      const fields = ctx.query.fields;
      let tmpFields = fields.split(",");
      for (let i = 0; i < tmpFields.length; i++) {
        if (tmpFields[i].trim() in schemaObj) {
          //Push
          selectFields.push(tmpFields[i].trim());
        }
      }
    }
    //If no field provided
    if (selectFields.length < 1) {
      for (const property in schemaObj) {
        selectFields.push(property);
      }
    }
    try {
      // Check if user exists
      const users = await DB.user.findAll(
        {
          attributes: selectFields,
        },
        { raw: true }
      );
      if (users.length > 0) {
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "Records Found!",
          data: users,
        });
      } else {
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "No Records Found!",
          data: [],
        });
      }
    } catch (err) {
      // console.log(err);
      return Response.error(ctx, {
        statusCode: 500,
        code: 50,
        msg: "Internal Error",
        error: err,
      });
    }
  };

  //Add Users
  static addUser = async (ctx, next) => {
    //Get Input
    const { name, email, mobile, address, password } = ctx.request.body;
    if (!name || !email || !password || !mobile || !address) {
      return Response.badRequest(ctx, {
        code: 40,
        msg: "Please provide valid data !",
      });
    }
    try {
      const Op = Sequelize.Op;
      // Check if user exists
      const checkUser = await DB.user.findAll({
        where: {
          [Op.or]: [{ email }, { mobile }],
        },
      });
      if (checkUser.length < 1) {
        //Hash the password
        const hash = Bcrypt.hashSync(password, 10);
        // Create a new user
        const newUser = await DB.user.create({
          name,
          email,
          mobile,
          address,
          isAdmin: false,
          password: hash,
        });
        //Remove password
        // const { password, ...data } = newUser.dataValues;
        return Response.created(ctx, {
          code: 21,
          msg: "User Added!",
          data: {
            id: newUser.id,
            name: newUser.name,
            email: newUser.email,
            mobile: newUser.mobile,
            address: newUser.address,
          },
        });
      } else {
        return Response.conflict(ctx, {
          code: 20,
          msg: "User already exits!",
        });
      }
    } catch (err) {
      console.log(err);
      return Response.error(ctx, {
        statusCode: 500,
        code: 50,
        msg: "Internal Error",
        error: err,
      });
    }
  };
  //Update User
  static updateUser = async (ctx, next) => {
    const userId = ctx.params.userId;
    const { name, email, mobile, password, address } = ctx.request.body;
    try {
      // Update a user
      let data = {};
      if (name) {
        data.name = name;
      }
      if (email) {
        data.email = email;
      }
      if (mobile) {
        data.mobile = mobile;
      }
      if (address) {
        data.address = address;
      }
      if (password) {
        //Hash the password
        const hash = Bcrypt.hashSync(password, 10);
        data.password = hash;
      }
      // Check if user exists
      const checkUser = await DB.user.findAll({
        where: {
          id: userId,
        },
      });
      if (checkUser.length == 1) {
        const updateUser = await DB.user.update(data, {
          where: { id: userId },
        });
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "User Details updated!",
        });
      } else {
        return Response.notFound(ctx, {
          code: 20,
          msg: "User does not exits!",
        });
      }
    } catch (err) {
      console.log(err);
      return Response.error(ctx, {
        statusCode: 500,
        code: 50,
        msg: "Internal Error",
        error: err,
      });
    }
  };
  //Delete User
  static deleteUser = async (ctx, next) => {
    const userId = ctx.params.userId;
    if (!userId) {
      return Response.badRequest(ctx, {
        code: 40,
        msg: "Please provide valid data !",
      });
    }
    try {
      // Check if user exists
      const checkUser = await DB.user.findAll({
        where: {
          id: userId,
        },
      });
      if (checkUser.length == 1) {
        const deleteUser = await DB.user.destroy({
          where: {
            id: userId,
          },
        });
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "User Removed!",
        });
      } else {
        return Response.notFound(ctx, {
          code: 20,
          msg: "User does not exits!",
        });
      }
    } catch (err) {
      console.log(err);
      return Response.error(ctx, {
        statusCode: 500,
        code: 50,
        msg: "Internal Error",
        error: err,
      });
    }
  };
};
