# AQM APIs

( Air Quality Monitoring Appication Backend )

## NPM Library Used

- Koa
- Postgres + Sequelizer
- Asynchronous Functions (Async/Await)

## Getting Started

```shell
$ git clone git@gitlab.com:hyperthingsiot/iot-platform/applications/aqm/backend.git
$ cd aqm-apis
```

## Project structure

Here's the default structure for your project files.

- **app**
  - **config**
    - adaptor.js (Config Adaptor)
  - **api**
    - **v1**
      - **controllers**
      - **routes**
      - **services**
      - **db**
      - **utils**
- app.js (Server Configuration)
- index.js (Server Configuration)

# Environment variables

(To begin with, we have to define some environment variables)

| Name            | App Specific       | Default | Required | Description | Valid | Notes |
| --------------- | ------------------ | ------- | :------: | ----------- | :---: | ----- |
| PGDB_HOST       | AQMS_PGDB_HOST     |         |   Yes    |             |       |       |
| PGDB_PORT       | AQMS_PGDB_PORT     |         |   Yes    |             |       |       |
| PGDB_IS_AUTH    | AQMS_PGDB_IS_AUTH  |         |   Yes    |             |       |       |
| PGDB_USERNAME   | AQMS_PGDB_USERNAME |         |   Yes    |             |       |       |
| PGDB_PASSWORD   | AQMS_PGDB_PASSWORD |         |   Yes    |             |       |       |
| PGDB_NAME       |                    |         |   Yes    |             |       |       |
|                 | AQMS_API_PORT      |         |   Yes    |             |       |       |
|                 | DS_API             |         |   Yes    |             |       |       |
| AQMS_DS_API_KEY |                    |         |   Yes    |             |       |       |

## Running

Install dependencies

```
npm install
```

Run Application in Development Env

```
$ npm run dev
```

Run Application in Production Env

```
$ npm start
```
